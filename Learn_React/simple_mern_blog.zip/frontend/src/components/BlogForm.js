import React, { useState } from "react";

function BlogForm() {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  const handleSubmit = async () => {
    await fetch("http://localhost:5000/api/blogs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, content }),
    });
    setTitle("");
    setContent("");
  };

  return (
    <div>
      <input placeholder="Title" value={title} onChange={(e)=>setTitle(e.target.value)} />
      <br />
      <textarea placeholder="Content" value={content} onChange={(e)=>setContent(e.target.value)} />
      <br />
      <button onClick={handleSubmit}>Add Blog</button>
    </div>
  );
}

export default BlogForm;