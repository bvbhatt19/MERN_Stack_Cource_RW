import React, { useEffect, useState } from "react";

function BlogList() {
  const [blogs, setBlogs] = useState([]);

  const fetchBlogs = async () => {
    const res = await fetch("http://localhost:5000/api/blogs");
    setBlogs(await res.json());
  };

  const deleteBlog = async (id) => {
    await fetch("http://localhost:5000/api/blogs/" + id, { method: "DELETE" });
    fetchBlogs();
  };

  useEffect(() => { fetchBlogs(); }, []);

  return (
    <div>
      <h2>All Blogs</h2>
      {blogs.map((b) => (
        <div key={b._id} style={{ border: "1px solid #ccc", margin: 10, padding: 10 }}>
          <h3>{b.title}</h3>
          <p>{b.content}</p>
          <button onClick={() => deleteBlog(b._id)}>Delete</button>
        </div>
      ))}
    </div>
  );
}

export default BlogList;