import React from "react";
import BlogForm from "./components/BlogForm";
import BlogList from "./components/BlogList";

function App() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Simple MERN Blog</h1>
      <BlogForm />
      <BlogList />
    </div>
  );
}
export default App;